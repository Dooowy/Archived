#include <iostream>
#include <opencv2/core.hpp>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;
string Framesource = "C:/DevSource/TrackerVid/1.png";
int ConstrainingX = 620;
int ConstrainingY = 420;

int Frame = 0;

int constraintX(int X)
{
    if (X < 0)
    {
        return 0;
    }
    if (X > ConstrainingX - 1) // 620
    {
        return ConstrainingX - 1;
    }
    if (X < ConstrainingX - 1)
    {
        return X;
    }
}

int constraintY(int Y)
{
    if (Y < 0)
    {
        return 0;
    }
    if (Y > ConstrainingY - 1)
    {
        return ConstrainingY - 1;
    }
    if (Y < ConstrainingY - 1)
    {
        return Y;
    }
}

void NextFrame()
{
    Frame++;
    if (Frame < 39)
    {
        string test = "C:/DevSource/TrackerVid/";
        test.append(std::to_string(Frame) + ".png");
        Framesource = test;
        cout << Framesource << "\n";
    }
    else
    {
        Frame = 0;
    }
}

void VisionThread()
{
    // declare variables
    //Vec3b UpperGreen = Vec3b(190, 255, 105);
    //Vec3b LowerGreen = Vec3b(20, 102, 0);
    Vec3b UpperGreen = Vec3b(252, 255, 252);
    Vec3b LowerGreen = Vec3b(225, 245, 225);
    Vec3b UpperGreen2 = UpperGreen;
    Vec3b LowerGreen2 = LowerGreen;
    Vec3b UpperGreen3 = UpperGreen;
    Vec3b LowerGreen3 = LowerGreen;

    //Vec3b UpperGreen = Vec3b(255, 255, 255);
    //Vec3b LowerGreen = Vec3b(250, 250, 250);
    //Vec3b UpperGreen2 = UpperGreen;
    //Vec3b LowerGreen2 = LowerGreen;
    //Vec3b UpperGreen3 = UpperGreen;
    //Vec3b LowerGreen3 = LowerGreen;

    bool AutonomousShooter = true;

    int selectorY_ = 1;
    int selectorX_ = 1;
    int selectorY2_ = 480;
    int selectorX2_ = 1;
    int ConstrainingX = 620 / 2;
    int ConstrainingY = 480 / 2;
    int PixelSkipY_ = 30;
    int PixelSkipX_ = 30;
    int PixelSkipY2_ = 30;
    int PixelSkipX2_ = 30;

    int PixelSkipMultiplier = 1;

    int DesiredPixelCount = 2;
    int TrackerTimeout = 100;
    int TargetLocked = 0;
    int AutoShooterActivated = -1000;
    int Flash = 0;
    bool IsObjectBeingTracked = false;
    int PixelFoundCount = 0;
    Point Target = Point(0, 0);
    Point ShootAt = Point(0, 0);
    Point TargetCorner1 = Point(0, 0);
    Point TargetCorner2 = Point(0, 0);
    Point Selector1 = Point(0, 0);
    Point Selector2 = Point(0, 0);

    int AutonomousTimer = 0;
    
    int TargetLockedTime = 0;

    int OffsetInX = -40;
    int OffsetInY = 20;


    // declare variables
    VideoCapture cap; // or 1 for laptop
    if (!cap.open(0)) {

    }
    while (1)
    {

            NextFrame();

        // Desktop Camera Essentials not RoboRIO essentials do not copy this over RoboRio draw code

        Mat frame;
        cap >> frame;
        //flip(frame, frame, +1);
        //frame = imread("C:/Users/Gaming/Desktop/Development/sample/sample_green_shades.png");
        //frame = imread("C:/Users/Gaming/Desktop/Development/sample/1.jpg");
        //frame = imread("C:/Users/Gaming/Desktop/Development/sample/LED.jpg");
        //cvSink.GrabFrame(mat);
        //frame = imread("C:/Users/Gaming/Desktop/Development/sample/2.jpg");
        //frame = imread("C:/DevSource/TrackerVid/1.png");
        //frame = imread(Framesource);

        if (frame.empty()) break;
        // Desktop Camera Essentials not RoboRIO essentials do not copy this over RoboRio draw code

        ConstrainingX = frame.cols - 1;
        ConstrainingY = frame.rows - 1;
        //draw code
        Mat Mask;
        inRange(frame, LowerGreen, UpperGreen, Mask);
        Mat Mask2;
        inRange(frame, LowerGreen2, UpperGreen2, Mask2);
        Mat Mask3;
        inRange(frame, LowerGreen3, UpperGreen3, Mask3);

        cv::Mat matD;
        cv::Mat FilteredMask;
        cv::add(Mask, Mask2, matD);
        cv::add(matD, Mask3, FilteredMask);
        Mat ErodedMask;
        erode(FilteredMask, ErodedMask, 200);
        FilteredMask = ErodedMask;

        // tessssssssssst
        cv::Mat Output;
        //imshow("frame", frame);
        Output = frame;
        Output.setTo(0, FilteredMask);

        Mat CameraOutput = frame;

        // check if this works scanner 

        // check if scan zones for white
        int length = 0;
        bool ColorFound1 = false;
        PixelFoundCount = 0;
        while (length < ConstrainingY)
        {
            length++;
            int Color = (int)FilteredMask.at<uchar>(constraintY(length - 1), constraintX(selectorX_));
            //cout << " CONSTRAINT VALUE IS " << Color << "\n";
            if (Color != 0)
            {
                PixelFoundCount++;
                if (PixelFoundCount > DesiredPixelCount)
                {
                    TrackerTimeout = 0;
                    Selector1.x = selectorX_;
                    ColorFound1 = true;
                }
            }
            //rectangle(CameraOutput, Rect(selectorX_, length, 1, 1), Scalar(0, 255, 0));
                //cout << "COLOR IS " << (int)Color << "\n";
        }
        if (ColorFound1)
        {
            selectorX_ = selectorX_ - PixelSkipX_ - 15;
            PixelSkipX_ = 15 * PixelSkipMultiplier;
        }

        // Scan Left to right for green
        length = 0;
        bool ColorFound2 = false;
        PixelFoundCount = 0;
        while (length < ConstrainingY)
        {
            length++;
            int Color = (int)FilteredMask.at<uchar>(constraintY(length - 1), constraintX(selectorX2_));
            //cout << " CONSTRAINT VALUE IS " << Color << "\n";
            if (Color != 0)
            {
                PixelFoundCount++;
                if (PixelFoundCount > DesiredPixelCount)
                {
                    TrackerTimeout = 0;
                    Selector2.x = selectorX2_;
                    ColorFound2 = true;
                }
            }
            //rectangle(CameraOutput, Rect(selectorX2_, length, 1, 1), Scalar(255, 0, 0));
            //cout << "COLOR IS " << (int)Color << "\n";
        }
        if (ColorFound2)
        {
            selectorX2_ = selectorX2_ + PixelSkipX2_ + 15;
            PixelSkipX2_ = 15 * PixelSkipMultiplier;
        }
        // Scan Right to left for green

        // Scan Top to bottom

        length = 0;
        bool ColorFound3 = false;
        PixelFoundCount = 0;
        while (length < selectorX2_ - selectorX_)
        {
            length++;
            int Color = (int)FilteredMask.at<uchar>(constraintY(selectorY_), constraintX(selectorX_ + length));
            //cout << " CONSTRAINT VALUE IS " << Color << "\n";
            if (Color != 0)
            {
                PixelFoundCount++;
                if (PixelFoundCount > DesiredPixelCount)
                {
                    TrackerTimeout = 0;
                    Selector1.y = selectorY_;
                    ColorFound3 = true;
                }
            }
            //rectangle(CameraOutput, Rect(length + selectorX_, selectorY_, 1, 1), Scalar(255, 0, 0));
            //cout << "COLOR IS " << (int)Color << "\n";
        }
        if (ColorFound3)
        {
            selectorY_ = selectorY_ - PixelSkipY_ - 15;
            PixelSkipY_ = 15 * PixelSkipMultiplier;
        }
        //
        length = 0;
        bool ColorFound4 = false;
        PixelFoundCount = 0;
        while (length < selectorX2_ - selectorX_)
        {
            length++;
            int Color = (int)FilteredMask.at<uchar>(constraintY(selectorY2_), constraintX(selectorX_ + length));
            //cout << " CONSTRAINT VALUE IS " << Color << "\n";
            if (Color != 0)
            {
                PixelFoundCount++;
                if (PixelFoundCount > DesiredPixelCount)
                {
                    TrackerTimeout = 0;
                    Selector2.y = selectorY2_;
                    ColorFound4 = true;
                }
            }
            //rectangle(CameraOutput, Rect(length + selectorX_, selectorY2_, 1, 1), Scalar(255, 0, 0));
            //cout << "COLOR IS " << (int)Color << "\n";
        }
        if (ColorFound4)
        {
            selectorY2_ = selectorY2_ + PixelSkipY2_ + 15;
            PixelSkipY2_ = 15 * PixelSkipMultiplier;
        }
        // check if scan zones for white
        selectorX_ = selectorX_ + PixelSkipX_;

        if (selectorX_ > ConstrainingX)
        {
            selectorX_ = ConstrainingX;
        }
        if (selectorX_ < 0)
        {
            selectorX_ = 0;
        }
        //
        selectorX2_ = selectorX2_ - PixelSkipX2_;

        if (selectorX2_ > ConstrainingX)
        {
            selectorX2_ = ConstrainingX;
        }
        if (selectorX2_ < 0)
        {
            selectorX2_ = ConstrainingX;
        }
        //
        selectorY_ = selectorY_ + PixelSkipY_;

        if (selectorY_ > ConstrainingY)
        {
            selectorY_ = ConstrainingY;
        }
        if (selectorY_ < 0)
        {
            selectorY_ = 0;
        }

        //

        selectorY2_ = selectorY2_ - PixelSkipY2_;

        if (selectorY2_ > ConstrainingY)
        {
            selectorY2_ = ConstrainingY;
        }
        if (selectorY2_ < 0)
        {
            selectorY2_ = 0;
        }

        // Target lost.

        if (selectorX_ - 30 < selectorX2_ && selectorX2_ < selectorX_ + 30)
        {
            PixelSkipX2_ = 30;
            PixelSkipX_ = 30;
            //cout << "TARGET IS THERE !!!" << selectorX_ - 20 << " < " << selectorX2_ << " < " << selectorX_ + 20 << "\n";
            selectorX2_ = ConstrainingX;
            selectorX_ = 0;
        }
        else
        {
            //cout << "TARGET ISNT THERE " << selectorX_ - 20 << " < " << selectorX2_ << " < " << selectorX_ + 20 << "\n";
        }

        if (selectorY_ - 30 < selectorY2_ && selectorY2_ < selectorY_ + 30)
        {
            PixelSkipY2_ = 30;
            PixelSkipY_ = 30;
            //cout << "TARGET IS THERE !!!" << selectorY_ - 20 << " < " << selectorY2_ << " < " << selectorY_ + 20 << "\n";
            selectorY2_ = ConstrainingY;
            selectorY_ = 0;
        }
        else
        {
            //cout << "TARGET ISNT THERE " << selectorY_ - 20 << " < " << selectorY2_ << " < " << selectorY_ + 20 << "\n";
        }
        // make the tracker for the y axis
    // make a shake compensator

        if (!((selectorX_ - 16) < Selector1.x && Selector1.x < (selectorX_ + 16)))
        {
            Selector1.x = selectorX_;
            //TargetCorner1.x = Selector1.x;

        }
        if (!((selectorX2_ - 16) < Selector2.x && Selector2.x < (selectorX2_ + 16)))
        {
            Selector2.x = selectorX2_;
            //TargetCorner2.x = Selector2.x;

        }
        if (!((selectorY_ - 16) < Selector1.y && Selector1.y < (selectorY_ + 16)))
        {
            Selector1.y = selectorY_;
            //TargetCorner1.y = Selector1.y;
        }
        if (!((selectorY2_ - 16) < Selector2.y && Selector2.y < (selectorY2_ + 16)))
        {
            Selector2.y = selectorY2_;
            //TargetCorner2.y = Selector2.y;
        }
        TrackerTimeout++;
        if (TrackerTimeout > 30)
        {
            IsObjectBeingTracked = false;
        }
        else
        {
            IsObjectBeingTracked = true;
        }
        PixelFoundCount = 0;
        ConstrainingX = FilteredMask.cols / 2;
        ConstrainingY = FilteredMask.rows / 2;
        // check if this works

        if (IsObjectBeingTracked)
        {
            rectangle(CameraOutput, Selector1, Selector2, Scalar(0, 255, 0), 1);
            Target.x = (Selector2.x + Selector1.x) / 2;
            Target.y = (Selector2.y + Selector1.y) / 2;
            circle(CameraOutput, Point(ShootAt.x, ShootAt.y), 7, Scalar(255, 0, 255), 2);
            circle(CameraOutput, Target, 4, Scalar(0, 0, 255), -1);
            line(CameraOutput, ShootAt, Point((620 / 2) + OffsetInX, (70 + 10) + OffsetInY), Scalar(0, 255, 0), 1);

            // rectangle(CameraOutput, TargetCorner1, TargetCorner2, Scalar(0, 0, 255));
            if (Flash > 5)
            {
                rectangle(CameraOutput, Point((590 / 2) + OffsetInX, (50 + 10) + OffsetInY), Point((650 / 2) + OffsetInX, (90 + 10) + OffsetInY), Scalar(0, 0, 255), 2);
            }
            else
            {
                rectangle(CameraOutput, Point((590 / 2) + OffsetInX, (50 + 10) + OffsetInY), Point((650 / 2) + OffsetInX, (90 + 10) + OffsetInY), Scalar(255, 0, 255), 2);
            }
            rectangle(CameraOutput, Point((590 / 2) + OffsetInX, (50 + 10) + OffsetInY), Point((650 / 2) + OffsetInX, (90 + 10) + OffsetInY), Scalar(0, 255, 0), 2);
        }
        else
        {
            rectangle(CameraOutput, Point((590 / 2) + OffsetInX, (50 + 10) + OffsetInY), Point((650 / 2) + OffsetInX, (90 + 10) + OffsetInY), Scalar(255, 0, 0), 2);
        }

        // hud
        circle(CameraOutput, Point((620 / 2) + OffsetInX, (70 + 10) + OffsetInY), 4, Scalar(255, 0, 255), -1);
        // rectangle(CameraOutput, Point(580 / 2, 50 + 10), Point(660 / 2, 90 + 10), Scalar(0, 255, 0));
        // tracking 
        if (IsObjectBeingTracked)
        {
            if ((590 / 2) + OffsetInX < ShootAt.x && ShootAt.x < (650 / 2) + OffsetInX)
            {
                if ((80 - 10) + OffsetInY < ShootAt.y && ShootAt.y < (90 + 10) + OffsetInY)
                {
                    if (AutonomousShooter)
                    {
                        //MotorLeft.Set(ControlMode(0), 0);
                        //MotorRight.Set(ControlMode(0), 0);

                    }
                    if (Flash > 5)
                    {
                        rectangle(CameraOutput, Point((590 / 2) + OffsetInX, (50 + 10) + OffsetInY), Point((650 / 2) + OffsetInX, (90 + 10) + OffsetInY), Scalar(255, 0, 255), 2);
                    }
                    else
                    {
                        rectangle(CameraOutput, Point(590 / 2, 50 + 10), Point(650 / 2, 90 + 10), Scalar(0, 255, 0), 2);
                    }
                    if (AutoShooterActivated < 0)
                    {
                        AutoShooterActivated = 0;
                    }
                    AutoShooterActivated++;
                }
            }
            else
            {
                putText(CameraOutput, " Aiming", Point(10, 45), 0, 1, Scalar(255, 255, 255));
                AutoShooterActivated = -1;
            }
            //cout << ShooterActivated << "\n";
        }
        else
        {
            AutoShooterActivated = AutoShooterActivated - 1;
        }
        //

        //
        if (-40 < AutoShooterActivated && AutoShooterActivated < -10)
        {
            putText(CameraOutput, " Target Lost :(", Point(10, 45), 0, 1, Scalar(255, 255, 255));
        }
        if (AutoShooterActivated > 1 && AutoShooterActivated < 3)
        {
            putText(CameraOutput, " Target found!", Point(10, 45), 0, 1, Scalar(255, 255, 255));
        }
        if (AutoShooterActivated > 2 && AutoShooterActivated < 5)
        {
            putText(CameraOutput, " Firing in 3", Point(10, 45), 0, 1, Scalar(255, 255, 255));
        }
        if (AutoShooterActivated > 5 && AutoShooterActivated < 10)
        {
            putText(CameraOutput, " Firing in 2", Point(10, 45), 0, 1, Scalar(255, 255, 255));
        }
        if (AutoShooterActivated > 10 && AutoShooterActivated < 15)
        {
            putText(CameraOutput, " Firing in 1", Point(10, 45), 0, 1, Scalar(255, 255, 255));
        }
        if (AutoShooterActivated > 15 && AutoShooterActivated < 100)
        {
            if (AutonomousShooter)
            {
                //MotorLeft.Set(ControlMode(0), 0);
                //MotorRight.Set(ControlMode(0), 0);
                //Motor1.Set(ControlMode(0), 1.0);
                /*if (EncoderMoterShooter.GetRate() > 50)
                {
                    Actuator.Set(-10.0);
                }
                if (EncoderMoterShooter.GetRate() < 8)
                {
                    Actuator.Set(10.0);
                }*/

                if (AutoShooterActivated > 79)
                {
                    //Actuator.Set(10.0);
                    //Motor1.Set(ControlMode(0), 0.0);
                    AutonomousShooter = false;
                }
            }
            if (Flash > 5)
            {
                putText(CameraOutput, " FIRING", Point(10, 45), 0, 1, Scalar(0, 0, 255));
            }
            else
            {
                putText(CameraOutput, " FIRING", Point(10, 45), 0, 1, Scalar(255, 255, 255));
            }
        }
        //cout << ShooterActivated << "\n";
        Flash++;
        if (Flash > 10)
        {
            Flash = 0;
        }

        // Locked in
        if (TrackerTimeout < 10)
        {
            TargetLockedTime++;
        }
        else
        {
            TargetLockedTime = 0;
        }

        if (TargetLockedTime > 10)
        {
            int TrackerPixelDistance = 25;
            cout << "Target Locked \n";
            int AdjustX = 0;
            int AdjustY = 0;
            int MultiplierX = 2;
            int MultiplierY = 1;


            int length = 0;

            while (length < Selector2.y - Selector1.y + TrackerPixelDistance*2)
            {
                length++;
                int color = FilteredMask.at<uchar>(constraintY(Selector1.y + length),constraintX(Selector2.x + TrackerPixelDistance));
                if (color != 0)
                {
                    AdjustX = TrackerPixelDistance * 1;
                }
                line(CameraOutput, Point(Selector2.x + TrackerPixelDistance, Selector1.y - TrackerPixelDistance), Point(Selector2.x + TrackerPixelDistance, Selector1.y + length - TrackerPixelDistance), Scalar(255, 0, 255));
            }
            length = 0;
            while (length < Selector2.y - Selector1.y + TrackerPixelDistance*2)
            {
                length++;
                int color = FilteredMask.at<uchar>(constraintY(Selector1.y + length), constraintX(Selector1.x - TrackerPixelDistance));
                if (color != 0)
                {
                    AdjustX = TrackerPixelDistance * -1;
                }
                line(CameraOutput, Point(Selector1.x - TrackerPixelDistance, Selector1.y - TrackerPixelDistance), Point(Selector1.x - TrackerPixelDistance, Selector1.y + length - TrackerPixelDistance), Scalar(255, 255, 255));
            }

            length = 0;
            while (length < Selector2.x - Selector1.x + TrackerPixelDistance*2)
            {
                length++;
                int color = FilteredMask.at<uchar>(constraintY(Selector1.y - TrackerPixelDistance), constraintX(Selector1.x - TrackerPixelDistance + length));
                if (color != 0)
                {
                    AdjustY = TrackerPixelDistance * -1;
                }
                line(CameraOutput, Point(Selector1.x - TrackerPixelDistance, Selector1.y - TrackerPixelDistance), Point(Selector1.x - TrackerPixelDistance + length, Selector1.y - TrackerPixelDistance), Scalar(255, 0, 255));
            }

            length = 0;

            while (length < Selector2.x - Selector1.x)
            {
                length++;
                int color = FilteredMask.at<uchar>(constraintY(Selector2.y + TrackerPixelDistance), constraintX(Selector2.x - length));
                if (color != 0)
                {
                    AdjustY = TrackerPixelDistance * 1;
                }
                line(CameraOutput, Point(Selector2.x, Selector2.y + TrackerPixelDistance), Point(Selector2.x - length, Selector2.y + TrackerPixelDistance), Scalar(255, 255, 255));
            }

            selectorY_ = selectorY_ + AdjustY * MultiplierY;
            selectorY2_ = selectorY2_ + AdjustY * MultiplierY;
            selectorX_ = selectorX_ + AdjustX * MultiplierX;
            selectorX2_ = selectorX2_ + AdjustX * MultiplierX;
            Selector1.x = Selector1.x + AdjustX * MultiplierX;
            Selector2.x = Selector2.x + AdjustX * MultiplierX;
            Selector1.y = Selector1.y + AdjustY * MultiplierY;
            Selector2.y = Selector2.y + AdjustY * MultiplierY;

        }
        // Shooter HUD

        // cross hair
        // line(CameraOutput, Point((ConstrainingX / 2) - 10, ConstrainingY / 2), Point((ConstrainingX / 2) + 10, ConstrainingY / 2), Scalar(100, 100, 100),2);
    //     line(CameraOutput, Point(ConstrainingX / 2, (ConstrainingY / 2) - 10), Point(ConstrainingX / 2, (ConstrainingY / 2) + 10), Scalar(100, 100, 100),2);

        ShootAt.x = (Selector2.x + Selector1.x) / 2;
        ShootAt.y = Selector1.y;

        // Shooting algorithm

        Point Crosshair = Point((620 / 2) + OffsetInX, (70 + 10) + OffsetInY);

        if (IsObjectBeingTracked)
        {
            if (Crosshair.x > ShootAt.x)
            {
                putText(CameraOutput, " Turning Left", Point(10, 360), 0, 1, Scalar(255, 255, 255));
            }
            if (Crosshair.x < ShootAt.x)
            {
                putText(CameraOutput, " Turning Right", Point(10, 360), 0, 1, Scalar(255, 255, 255));
            }
            if (Crosshair.y > ShootAt.y)
            {
                putText(CameraOutput, " Backward", Point(10, 320), 0, 1, Scalar(255, 255, 255));
            }
            if (Crosshair.y < ShootAt.y)
            {
                putText(CameraOutput, " Forward", Point(10, 320), 0, 1, Scalar(255, 255, 255));
            }
        }

        if (AutonomousShooter)
        {
            if (Flash > 5)
            {
                putText(CameraOutput, " Auto-shooter enabled", Point(10, 400), 0, 1, Scalar(255, 255, 255));
            }
            else
            {
                putText(CameraOutput, " Auto-shooter enabled", Point(10, 400), 0, 1, Scalar(0, 0, 255));
            }
            putText(CameraOutput, " Press B button to stop auto-shooter", Point(10, 440), 0, 1, Scalar(255, 255, 255));
            // Autonomous Variables for moving bot
            double AutoSteering = (((double)ShootAt.x - (double)Crosshair.x)) / ConstrainingX;
            double AutoForward = (((double)ShootAt.y - (double)Crosshair.y)) / ConstrainingY;
            if (AutoForward < 0)
            {
                AutoForward = AutoForward * 3;
            }
            double finalMotorPowerLeft = 0;
            double finalMotorPowerRight = 0;
            double finalMotorPowerLeft2 = 0;
            double finalMotorPowerRight2 = 0;

            // if(AutoSteering > 0.08)
            // {
            //   finalMotorPowerLeft = 0.4;
            //   finalMotorPowerRight = 0.4;
            // }
            // if(AutoSteering < 0.08)
            // {
            //   finalMotorPowerLeft = -0.4;
            //   finalMotorPowerRight = -0.4;
            // } 

            // Auto-shooter
            //
            if (TrackerTimeout < 2)
            {
                //cout << (double)AutoSteering << " - " << (double)AutoForward << "\n";
                //cout << (double)AutoSteering << " - " << (double)AutoForward << "\n";
                // cout << (double)finalMotorPowerLeft << " - " << (double)finalMotorPowerRight << "\n";
                if (AutoShooterActivated > 2 && AutoShooterActivated < 320)
                {

                    // Motor1.Set(ControlMode(0),1.0);
                    // if(EncoderMoterShooter.GetRate() > 20 )
                    // {
                    //   Actuator.Set(-10.0);
                    // }
                    // if(EncoderMoterShooter.GetRate() < 8 )
                    // {
                    //   Actuator.Set(10.0);
                    // }
                }
                else if (AutoShooterActivated < 2)
                {
                    if (1 > AutoSteering&& AutoSteering > 0.33)
                    {
                        // cout << "Turn a little right" << "\n";
                        finalMotorPowerLeft = 0.4;
                        finalMotorPowerRight = 0.4;
                    }
                    if (-1 < AutoSteering && AutoSteering < -0.33)
                    {
                        // cout << "Turn a little Left" << "\n";
                        finalMotorPowerLeft = -0.4;
                        finalMotorPowerRight = -0.4;
                    }
                    if (0.33 > AutoSteering&& AutoSteering > 0.21)
                    {
                        // cout << "Turn a little-2 right" << "\n";
                        finalMotorPowerLeft = 0.35;
                        finalMotorPowerRight = 0.35;
                    }
                    if (-0.33 < AutoSteering && AutoSteering < -0.21)
                    {
                        // cout << "Turn a little-2 Left" << "\n";
                        finalMotorPowerLeft = -0.35;
                        finalMotorPowerRight = -0.35;
                    }
                    if (0.21 > AutoSteering&& AutoSteering > 0.05)
                    {
                        // cout << "Turn a little-3 right" << "\n";
                        finalMotorPowerLeft = 0.25;
                        finalMotorPowerRight = 0.25;
                    }
                    if (-0.21 < AutoSteering && AutoSteering < -0.05)
                    {
                        // cout << "Turn a little-3 Left" << "\n";
                        finalMotorPowerLeft = -0.25;
                        finalMotorPowerRight = -0.25;
                    }
                    if (0.05 > AutoSteering&& AutoSteering > 0.03)
                    {
                        // cout << "Turn a little-4 right" << "\n";
                        finalMotorPowerLeft = 0.22;
                        finalMotorPowerRight = 0.22;
                    }
                    if (-0.05 < AutoSteering && AutoSteering < -0.03)
                    {
                        // cout << "Turn a little-4 Left" << "\n";
                        finalMotorPowerLeft = -0.25;
                        finalMotorPowerRight = -0.25;
                    }
                    if (0.03 > AutoSteering&& AutoSteering > 0.0003)
                    {
                        // cout << "STOP MOTOR TURNING" << "\n";
                        finalMotorPowerLeft = 0;
                        finalMotorPowerRight = 0;
                    }
                    if (-0.03 < AutoSteering && AutoSteering < -0.0003)
                    {
                        // cout << "STOP MOTOR TURNING" << "\n";
                        finalMotorPowerLeft = -0;
                        finalMotorPowerRight = -0;
                    }

                    // Auto Forwarding


                    if (1 > AutoForward&& AutoForward > 0.33)
                    {
                        // cout << "forward a little " << "\n";
                        finalMotorPowerLeft2 = -0.20;
                        finalMotorPowerRight2 = 0.20;
                    }
                    if (-1 < AutoForward && AutoForward < -0.33)
                    {
                        // cout << "backward a little " << "\n";
                        finalMotorPowerLeft2 = 0.20;
                        finalMotorPowerRight2 = -0.20;
                    }
                    if (0.33 > AutoForward&& AutoForward > 0.21)
                    {
                        // cout << "forward a little-2 " << "\n";
                        finalMotorPowerLeft2 = -0.18;
                        finalMotorPowerRight2 = 0.18;
                    }
                    if (-0.33 < AutoForward && AutoForward < -0.21)
                    {
                        // cout << "backward a little-2 " << "\n";
                        finalMotorPowerLeft2 = 0.18;
                        finalMotorPowerRight2 = -0.18;
                    }
                    if (0.21 > AutoForward&& AutoForward > 0.05)
                    {
                        // cout << "forward2 a little-3 " << "\n";
                        finalMotorPowerLeft2 = -0.15;
                        finalMotorPowerRight2 = 0.15;
                    }
                    if (-0.21 < AutoForward && AutoForward < -0.05)
                    {
                        // cout << "backward a little-3 " << "\n";
                        finalMotorPowerLeft2 = 0.15;
                        finalMotorPowerRight2 = -0.15;
                    }
                    if (0.05 > AutoForward&& AutoForward > 0.03)
                    {
                        // cout << "forward a little-4 " << "\n";
                        finalMotorPowerLeft2 = -0.15;
                        finalMotorPowerRight2 = 0.15;
                    }
                    if (-0.05 < AutoForward && AutoForward < -0.03)
                    {
                        // cout << "backward a little-4 " << "\n";
                        finalMotorPowerLeft2 = 0.15;
                        finalMotorPowerRight2 = -0.15;
                    }
                    if (0.03 > AutoForward&& AutoForward > 0.0003)
                    {
                        // cout << "STOP MOTOR FORWARD" << "\n";
                        finalMotorPowerLeft2 = 0.0;
                        finalMotorPowerRight2 = 0.0;
                    }
                    if (-0.03 < AutoForward && AutoForward < -0.0003)
                    {
                        // cout << "STOP MOTOR FORWARD" << "\n";
                        finalMotorPowerLeft2 = 0.0;
                        finalMotorPowerRight2 = 0.0;
                    }

                    // Auto-shooter movement
                    if (AutoShooterActivated < 5)
                    {
                        if (AutonomousTimer < 10 && AutonomousTimer > 5)
                        {
                            //MotorLeft.Set(ControlMode(0), finalMotorPowerLeft);
                            //MotorRight.Set(ControlMode(0), finalMotorPowerRight);
                        }
                    }
                    if (AutonomousTimer == 10)
                    {
                        //MotorLeft.Set(ControlMode(0), 0.0);
                        //MotorRight.Set(ControlMode(0), 0.0);
                    }
                    else if (AutonomousTimer < 20 && AutonomousTimer > 15)
                    {
                        //MotorLeft.Set(ControlMode(0), finalMotorPowerLeft2 * -1);
                        //MotorRight.Set(ControlMode(0), finalMotorPowerRight2 * -1);
                    }
                    if (AutonomousTimer == 1)
                    {
                        //MotorLeft.Set(ControlMode(0), 0.0);
                        //MotorRight.Set(ControlMode(0), 0.0);
                    }
                    // if(AutonomousTimer > 3)
                    // {
                    //   MotorLeft.Set(ControlMode(0),finalMotorPowerLeft);
                    //   MotorRight.Set(ControlMode(0),finalMotorPowerRight);
                    // }
                    // else
                    // {
                    //   MotorLeft.Set(ControlMode(0),finalMotorPowerLeft2 * -1);
                    //   MotorRight.Set(ControlMode(0),finalMotorPowerRight2 * -1);
                    // }
                } // end of tracker


                // set motors here
            }

            //
        }
        else
        {
            AutoShooterActivated = -10;
            putText(CameraOutput, " Auto-shooter disabled", Point(10, 400), 0, 1, Scalar(255, 255, 255));
            putText(CameraOutput, " Press B button to start Auto-shooter", Point(10, 440), 0, 1, Scalar(255, 255, 255));
        }
        // hud

                //draw code

        //cout << ConstrainingX << " and " << ConstrainingY << "\n";

        //auto channels = std::vector<cv::Mat>{ Mask, frame };
        imshow("Output 2", FilteredMask);
        imshow("Output", CameraOutput);
        if (waitKey(1) == 27) break;
    }
}

int main()
{
    cout << "Hello World!\n";
    VisionThread();
}
